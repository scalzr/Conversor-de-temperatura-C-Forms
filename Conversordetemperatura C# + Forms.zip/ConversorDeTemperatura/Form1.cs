using System;
using System.Windows.Forms;

namespace ConversorDeTemperatura
{
    public partial class Form1 : Form
    {
        // Defina os componentes como variáveis de instância
        private Label labelCelsius;
        private TextBox textBoxCelsius;
        private Button buttonConvert;
        private Label labelFahrenheit;

        public Form1()
        {
            InitializeComponent();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Inicialize os componentes
            labelCelsius = new Label() { Text = "Celsius:", Left = 10, Top = 20, Width = 50 };
            textBoxCelsius = new TextBox() { Left = 70, Top = 20, Width = 100 };
            buttonConvert = new Button() { Text = "Converter", Left = 70, Top = 50, Width = 100 };
            labelFahrenheit = new Label() { Text = "Fahrenheit:", Left = 10, Top = 80, Width = 150 };

            buttonConvert.Click += new EventHandler(ButtonConvert_Click);

            // Adicione os componentes ao formulário
            Controls.Add(labelCelsius);
            Controls.Add(textBoxCelsius);
            Controls.Add(buttonConvert);
            Controls.Add(labelFahrenheit);
        }

        private void ButtonConvert_Click(object sender, EventArgs e)
        {
            // Verifique se o valor de entrada é válido
            if (double.TryParse(textBoxCelsius.Text, out double celsius))
            {
                // Converta para Fahrenheit e mostre o resultado
                double fahrenheit = (celsius * 9 / 5) + 32;
                labelFahrenheit.Text = $"Fahrenheit: {fahrenheit}";
            }
            else
            {
                MessageBox.Show("Por favor, insira um valor numérico válido para Celsius.");
            }
        }
    }
}



